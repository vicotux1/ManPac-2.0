﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Controller: MonoBehaviour {

    [Header ("Movimiento")]
    [SerializeField]
    string _Horizontal = "Horizontal";
    [SerializeField]
    [Range(1f,10f)]
    float _speed = 5.0f;
    [Header("Salto")]
    [SerializeField]
    string _Salto = "Jump";
    Animator anim;
    public Camera _camera;
    public Vector2 seguir;


	void Start ()
    {
        anim = GetComponent<Animator>();
        

    }
    void LateUpdate()
    {
        _camera.transform.position = new Vector3(seguir.x+ transform.position.x, transform.position.y+4.5f,-6);
    }

    void Update ()
    {
        Move();
        Salto();
    }
    void Move()
    {
        float horizontal = Input.GetAxisRaw(_Horizontal);
        transform.Translate(new Vector2(horizontal, 0) * Time.deltaTime * _speed);

        if (horizontal < 0)
        {
            anim.SetFloat("speed", -1.0f);
            anim.SetBool("jump", false);
        }
        else if (horizontal > 0)
        {
            anim.SetFloat("speed", 1.0f);
            anim.SetBool("jump", false);
        }

        else
        {
            anim.SetFloat("speed", 0.0f);
            anim.SetBool("jump", false);
        }
    }
    void Salto()
        {
        if (Input.GetButtonDown(_Salto))
        {
            anim.SetBool("jump", true);
           transform.Translate(Vector2.up* 2.5f);
        }
    }
}
